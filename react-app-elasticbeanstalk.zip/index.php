﻿<?php
// PHP router for React SPA
$request_uri = $_SERVER['REQUEST_URI'];
$file_path = __DIR__ . $request_uri;

// If it's a static file that exists, serve it
if (file_exists($file_path) && is_file($file_path)) {
    // Set appropriate content type
    $extension = pathinfo($file_path, PATHINFO_EXTENSION);
    $mime_types = [
        'html' => 'text/html',
        'css' => 'text/css',
        'js' => 'application/javascript',
        'json' => 'application/json',
        'png' => 'image/png',
        'jpg' => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'gif' => 'image/gif',
        'svg' => 'image/svg+xml',
        'ico' => 'image/x-icon'
    ];
     
    if (isset($mime_types[$extension])) {
        header('Content-Type: ' . $mime_types[$extension]);
    }
     
    readfile($file_path);
    exit;
}

// For SPA routing, serve index.html for all other requests
if (file_exists(__DIR__ . '/index.html')) {
    header('Content-Type: text/html');
    readfile(__DIR__ . '/index.html');
} else {
    http_response_code(404);
    echo 'File not found';
}
?>
